# AGENTS.md - DotaOps Backend Instructions

## Role

Act as a senior Java Spring Boot backend developer, backend architect, database designer, security reviewer, and API reviewer.

The goal is production-quality backend code for DotaOps: correct, secure, maintainable, testable, and compatible with the existing frontend, database, and deployment setup.

## Backend Phase

The backend is ready for Iteration 4 work.

Do not treat this file as a feature specification or backlog. It defines how backend code should be written and reviewed. The actual application behavior for each Iteration 4 task must come from the current user request, issue, or accepted design.

Preserve already implemented Iteration 1, Iteration 2, and Iteration 3 behavior unless the user explicitly asks to change it.

Iteration 4 changes must stay compatible with the existing frontend contracts, Flyway-managed database schema, Supabase/RLS model, and documented tournament operations behavior. Do not add future-scope endpoints, roles, or database structures unless the current task explicitly requires them.

## Technology Stack

Use the existing backend stack:

- Java 21
- Spring Boot
- Spring MVC / WebMVC
- Spring Security
- Bean Validation
- PostgreSQL / Supabase PostgreSQL
- Flyway
- Maven wrapper

Do not introduce Liquibase.

Introduce new dependencies only when necessary and justified.

## Architecture

Use a layered, feature-oriented Spring Boot architecture.

Keep responsibilities separated:

- controllers handle HTTP only
- DTOs define API input/output contracts
- services own use cases, authorization, transactions, and business rules
- repositories own database access only
- domain objects represent backend concepts
- integration clients isolate external systems
- mappers transform data only
- configuration classes wire infrastructure only

Prefer package organization by domain feature, consistent with the existing codebase.

Do not access repositories directly from controllers.

Do not expose persistence entities through REST APIs.

Do not put business rules in controllers, mappers, repository methods, or configuration classes.

## Controller Rules

Controllers should:

- expose REST endpoints
- accept request DTOs
- use Bean Validation for request shape validation
- delegate to one service use case where practical
- return response DTOs
- use predictable HTTP status codes

Controllers must not:

- access repositories directly
- expose persistence entities
- call external APIs directly
- calculate analytics directly
- decide resource ownership or permissions without service-level verification
- contain tournament, registration, team, roster, match, import, or analytics business rules

## Service Rules

Services own application use cases.

Use services for:

- authorization checks
- resource ownership and membership rules
- state transitions
- date and settings validation
- registration, roster, match, result, import, and analytics orchestration
- audit-worthy business actions
- coordination of multiple repositories

Use:

```java
@Transactional
```

for write operations that must be atomic.

Use:

```java
@Transactional(readOnly = true)
```

for read-heavy service methods when useful.

Keep transaction scope small.

Do not keep database transactions open while waiting for external APIs.

## Repository Rules

Repositories own database access only.

Use existing repository style and query patterns.

Use explicit queries, projections, or DTO queries for non-trivial or read-heavy endpoints.

Avoid loading large object graphs unnecessarily.

Avoid N+1 query problems.

Repositories must not:

- contain business rules
- perform authorization decisions
- call external APIs
- return data that forces controllers to expose persistence internals

## Entity, Domain, And DTO Rules

Persistence mappings must match the Flyway-managed schema.

Use lazy relationships by default when using JPA entities unless there is a clear reason not to.

Use enums only for stable lifecycle values.

Do not shape persistence models around one frontend screen.

Use DTOs for all API input and output.

Request DTOs should include:

- only fields clients may send
- Bean Validation annotations
- clear required/optional semantics
- no server-owned fields such as audit values, ownership values, timestamps, or computed statuses unless the endpoint explicitly allows them

Response DTOs should include:

- only fields clients need
- stable field names
- no secrets
- no internal implementation details
- public-safe data for public endpoints

For PATCH-style requests:

- omitted optional field means "preserve existing value"
- explicit `null` for nullable optional field means "clear value"
- required fields must not be clearable

## API Rules

Use consistent REST naming.

Prefer:

- plural nouns
- existing `/api/...` prefix
- nested routes only when ownership is clearer
- stable response shapes for frontend compatibility

Use predictable HTTP status codes:

- `200 OK` for reads and updates
- `201 Created` for created resources
- `204 No Content` for successful deletes when no body is returned
- `400 Bad Request` for validation errors
- `401 Unauthorized` for missing authentication
- `403 Forbidden` for failed authorization
- `404 Not Found` for missing resources
- `409 Conflict` for duplicates, invalid state transitions, or state conflicts
- `500 Internal Server Error` only for unexpected failures

All collection endpoints must use pagination or bounded limits.

Public endpoints must return only public-safe data.

Private endpoints must be explicitly authenticated and service-authorized.

Breaking API changes require explicit user approval or a matching frontend/backend coordination task.

## Error Handling

Use centralized exception handling with `@ControllerAdvice`.

Return consistent error responses with:

- timestamp
- HTTP status
- error code
- message
- request path
- validation details when relevant

Use domain-specific exceptions for expected business failures.

Do not leak stack traces or internal exception details to API clients.

Do not log secrets.

Expected validation and authorization failures should not be logged as noisy server errors.

## Security Rules

Default to secure behavior.

Enforce authorization in backend service logic, even when `SecurityConfig` also protects the endpoint.

Do not trust frontend-provided:

- role
- user ID
- profile ID
- team ID
- organizer ID
- owner ID
- status
- checked-in timestamps
- audit fields
- ownership claims

Use the authenticated actor from backend security context.

Current compatibility note: DotaOps allows users to become organizers for self-service tournament creation. Do not treat self-selected organizer status as a bug unless the current task explicitly changes that product decision. Still scope organizer actions to the concrete resource where the domain requires resource ownership.

Use `profileId` as the primary identity for player/profile/team ownership.

Keep `authUserId` nullable where existing Steam-only flows require it.

Require `authUserId` only for flows that truly need Supabase auth identity.

Anonymous users must be blocked from protected writes.

Never hardcode credentials.

CORS must be explicit and environment/config based.

Authorization headers, JWTs, cookies, session tokens, API keys, and service role keys must never be logged.

## Role And Permission Rules

Preserve the current role and permission behavior unless a task explicitly changes it.

Prefer resource-scoped authorization over broad global checks.

Iteration 3 compatibility note: tournament operations are organizer/admin controlled. Referee, score reporter, analyst, observer, and similar concepts must stay tournament/resource-scoped unless a dedicated task defines a broader model. Do not introduce new global login roles for these concepts without explicit product approval.

Team captain behavior should be checked from current team data, not inferred from a broad global role, unless the existing code or task explicitly says otherwise.

Existing legacy staff role values must not be destructively removed without a dedicated migration task.

Do not grant write access to a role merely because the role name exists in the database. Add permissions only when the current task defines the allowed action and scope.

When adding or changing permission checks, cover both successful access and negative authorization tests.

## Supabase And RLS Rules

Supabase/PostgreSQL is the production database target.

For schema or policy changes:

- use Flyway migrations
- review affected RLS policies
- keep policies conservative
- map Supabase users through `auth.uid()` to `profiles.auth_user_id` when using auth user identity
- preserve Steam-only profile support where `auth_user_id` can be null
- keep `security definer` helpers minimal and schema-qualified
- control `search_path` in `security definer` functions
- place private helper functions in the existing private schema pattern

Do not expose service role keys to the frontend.

Do not rely on user-editable metadata for sensitive authorization unless the current product decision explicitly treats that value as self-service and non-privileged.

If automated tests use H2, manually review PostgreSQL/Supabase-specific SQL before finishing.

## Database And Migration Rules

Use Flyway only.

Never edit an already-applied migration unless the user explicitly confirms a local-only reset.

For schema changes:

- create a new migration
- keep persistence mappings aligned with schema
- use explicit primary keys
- use foreign keys
- use unique constraints for business uniqueness
- add indexes for frequent lookups and foreign keys
- use `NOT NULL` where required
- use `CHECK` constraints for stable invariants
- use `bigint` for Dota match IDs
- use `jsonb` for raw external payloads or controlled flexible structures
- use `timestamptz` for real timestamps

Migrations must be PostgreSQL-compatible and safe for existing data.

Spring JPA must validate the schema.

Keep:

```properties
spring.jpa.hibernate.ddl-auto=validate
```

## Transactions, Concurrency, And Idempotency

Wrap multi-step writes in transactions when partial writes would corrupt domain state.

Use database constraints as the final protection for critical uniqueness or race-sensitive rules.

Convert database constraint violations into clean API errors.

Keep external calls outside database transactions.

Make repeated import or external-ID based operations idempotent where practical.

Review concurrent status changes carefully when changing lifecycle behavior.

## External Integration Rules

Treat external systems as unreliable.

External API clients must:

- be isolated behind client/integration classes
- have explicit connect and read timeouts
- validate responses before storing or processing
- convert provider failures into useful backend errors
- avoid leaking large raw payloads to normal frontend responses

Unit tests must mock external APIs.

Non-essential external bootstrap work must not block login/session creation.

## Logging And Audit Rules

Logs must be useful, low-noise, and free of secrets.

Log unexpected failures once with safe identifiers.

Do not log full request bodies when they may contain sensitive data.

Important business actions should use the existing audit pattern when audit support exists for that area.

Audit payloads must not contain tokens, secrets, authorization headers, cookies, or sensitive request bodies.

## Performance Rules

Avoid N+1 queries.

Use pagination or bounded limits for lists.

Use projections or targeted queries for read-heavy endpoints.

Avoid loading large JSONB payloads unless needed.

Do not calculate expensive analytics in controllers.

Keep connection pool settings conservative unless measured.

Add indexes for new foreign keys and frequent lookup columns.

## Testing Rules

Add or update tests for meaningful backend behavior changes.

Use unit tests for:

- service business rules
- validation logic
- mapping logic
- authorization decisions
- status transitions
- failure handling

Use controller tests for:

- request validation
- HTTP status codes
- response shapes
- security behavior at the web layer

Use integration tests for:

- Flyway migrations
- repository queries
- database constraints
- Spring context
- RLS-sensitive behavior where a real PostgreSQL/Supabase database is required

Mock OpenDota, Steam, and other external services in unit tests.

Unit tests must not call live external APIs.

Before finishing backend work, run the most relevant command.

Default backend command:

```powershell
.\mvnw.cmd test "-Dspring.profiles.active=test"
```

For broader verification:

```powershell
.\mvnw.cmd verify "-Dspring.profiles.active=test"
```

Integration tests:

```powershell
.\mvnw.cmd "-Dtest=*IntegrationTest" test "-Dspring.profiles.active=integration"
```

Run integration tests only with safe non-production credentials.

If tests are skipped because required env vars are missing, report that clearly.

## Review Checklist Before Finishing

Before reporting completion, verify:

- code compiles when code changed
- tests were added or updated when behavior changed
- relevant tests were run
- DTOs are used instead of entities
- transactions are appropriate
- validation is present
- errors are handled consistently
- authorization is enforced in service logic
- no secrets were added
- external APIs have timeouts
- no unrelated files were changed
- no already-applied migration was modified
- implementation follows existing project style
- solution is not overengineered
- frontend and backend contracts remain compatible

## Output Expectations

When completing backend work, report:

1. summary of what changed
2. files changed
3. database migrations added or changed
4. API changes
5. tests added or updated
6. exact commands run
7. test results
8. assumptions made
9. remaining risks or TODOs
10. suggested Conventional Commit message or commit groups

Do not commit or push.
